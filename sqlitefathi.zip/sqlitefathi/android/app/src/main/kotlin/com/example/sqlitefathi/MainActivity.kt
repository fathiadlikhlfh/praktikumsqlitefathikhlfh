package com.example.sqlitefathi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
